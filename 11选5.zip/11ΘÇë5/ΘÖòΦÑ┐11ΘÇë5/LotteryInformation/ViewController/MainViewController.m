//
//  MainViewController.m
//  LotteryInformation
//
//  Created by 邹壮壮 on 2017/2/24.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "MainViewController.h"
#import "RadarButton.h"
#import <AVFoundation/AVFoundation.h>
#import <Masonry.h>
#import "UserStore.h"
#import "OpencodeModel.h"
#import "FristTableViewController.h"
#import "SecondTableViewController.h"
#import "ThirdTableViewController.h"
#import "LNWebViewController.h"
#import "CKAlertViewController.h"
#import <AFNetworking.h>
#import "UIColor+Extension.h"
#define KScal [UIScreen mainScreen].bounds.size.width/375
@interface MainViewController ()<AVAudioPlayerDelegate>
@property (nonatomic, strong)AVAudioPlayer *audioPlayer;
@property (strong, nonatomic)  UIView *backGifView;

@property (strong, nonatomic)  UILabel *originNumberLable;
@property (strong, nonatomic)  UIButton *sizeNumberBtn;
@property (strong, nonatomic)  UIButton *SingleOrDoubleBtn;
@property (strong, nonatomic)  UIButton *helpBtn;
@property (strong, nonatomic)  UIView *bottomView;
@property (nonatomic, strong) UIImageView *ballImageView;
@property (nonatomic, strong) NSMutableArray *dataArray;

@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithHexString:@"#c24800"];
    AVAudioSession *session = [AVAudioSession sharedInstance];
    [session setActive:YES error:nil];
    [session setCategory:AVAudioSessionCategoryPlayback error:nil];
    [self setUI];
     [self AFNetworkReachabilityStatus];
    // Do any additional setup after loading the view from its nib.
}
- (void)loadData{
   [UserStore getAnalyseopencode:kcode sucess:^(NSURLSessionDataTask *task, id responseObject) {
       NSNumber *codeNum = [responseObject objectForKey:@"code"];
       NSInteger code = [codeNum integerValue];
       if (code == 1) {
           NSArray *arr = [responseObject objectForKey:@"open_data"];
           for (NSDictionary *dict in arr) {
               OpencodeModel *model = [[OpencodeModel alloc]initWithDictionary:dict error:nil];
               [self.dataArray addObject:model];
           }
           if (_dataArray.count > 0) {
               OpencodeModel *model = [_dataArray firstObject];
               [self ball:model];
           }
       }
 
   } failure:^(NSURLSessionDataTask *task, NSError *error) {
       
   }];
}
- (NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
- (void)ball:(OpencodeModel *)model{
    CGFloat start_x = 35;
    CGFloat space = 17;
    CGFloat width = 30;
    CGFloat top = 25;
    for (NSInteger i=0; i<model.numberArr.count; i++) {
        NSString *ballStr = [model.numberArr objectAtIndex:i];
        UILabel *lable = [[UILabel alloc]init];
        lable.textAlignment = NSTextAlignmentCenter;
        lable.text = ballStr;
        [lable sizeToFit];
        [_ballImageView addSubview:lable];
        lable.frame = CGRectMake(start_x+(width+space)*i, top, width, CGRectGetHeight(lable.frame));
    }
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    UIView *view = [self.view viewWithTag:101];
    if (view) {
        for (UIView *viewsub in view.subviews) {
            [viewsub removeFromSuperview];
        }
        [view removeFromSuperview];
    }
    RadarButton *originNumberBtn = [[RadarButton alloc]init];
    originNumberBtn.tag = 101;
    [originNumberBtn addTarget:self action:@selector(originAction:) forControlEvents:UIControlEventTouchUpInside];
    originNumberBtn.backgroundColor = [UIColor colorWithHexString:@"#c24800"];;
    [self.view addSubview:originNumberBtn];
    
    [originNumberBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(110*KScal, 110*KScal));
        make.center.mas_equalTo(self.view);
    }];
    self.originNumberLable = [[UILabel alloc]init];
    _originNumberLable.text = @"开奖号码";
    _originNumberLable.textAlignment = NSTextAlignmentCenter;
    _originNumberLable.layer.masksToBounds = YES;
    _originNumberLable.layer.cornerRadius = 110*KScal/2;
    _originNumberLable.textColor = RGBA(16, 57, 62, 1);
    _originNumberLable.backgroundColor = [UIColor whiteColor];
    [originNumberBtn addSubview:self.originNumberLable];
    [self.originNumberLable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(originNumberBtn);
        make.center.mas_equalTo(originNumberBtn);
    }];
}
- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self.audioPlayer play];
    [self checkUpdate];
}
- (void)setUI{
    self.backGifView=[[UIView alloc]init];
    _backGifView.backgroundColor = [UIColor redColor];
    [self.view addSubview:self.backGifView];
    [self.backGifView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.view);
        make.top.mas_equalTo(self.view);
        make.right.mas_equalTo(self.view);
        make.height.mas_equalTo(160*KScal);
    }];
     [self gifPlay1];
    self.ballImageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"KaijiangBalls"]];
    [self.backGifView addSubview:self.ballImageView];
    [self.ballImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.mas_equalTo(self.backGifView);
    }];
    
    
    
    CGFloat space = 20*KScal;
    CGFloat bottom = -50*KScal;
    CGFloat widthBtn = ([UIScreen mainScreen].bounds.size.width-3*space)/3;
    //大小
    UIButton *sizeNumberBtn = [[UIButton alloc]init];
    [sizeNumberBtn setImage:[UIImage imageNamed:@"daxiao"] forState:UIControlStateNormal];
    [sizeNumberBtn addTarget:self action:@selector(sizeAction:) forControlEvents:UIControlEventTouchUpInside];
 
    [self.view addSubview:sizeNumberBtn];
    //单双
    UIButton *SingleOrDoubleBtn = [[UIButton alloc]init];
    
    [SingleOrDoubleBtn setImage:[UIImage imageNamed:@"danshuang"] forState:UIControlStateNormal];
    [SingleOrDoubleBtn addTarget:self action:@selector(singleOrDoubleAction:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:SingleOrDoubleBtn];
    //关于
    UIButton *helpBtn = [[UIButton alloc]init];
    
    [helpBtn setImage:[UIImage imageNamed:@"wode"] forState:UIControlStateNormal];
    [helpBtn addTarget:self action:@selector(helpAction:) forControlEvents:UIControlEventTouchUpInside];
   
    [self.view addSubview:helpBtn];
    [sizeNumberBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(widthBtn, widthBtn));
        make.left.mas_equalTo(self.view.mas_left).with.offset(10*KScal);
        make.bottom.mas_equalTo(self.view.mas_bottom).with.offset(bottom);
    }];
    [SingleOrDoubleBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(widthBtn, widthBtn));
        make.left.mas_equalTo(sizeNumberBtn.mas_right).with.offset(space);
        make.bottom.mas_equalTo(self.view.mas_bottom).with.offset(bottom);
    }];
    [helpBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(widthBtn, widthBtn));
        make.left.mas_equalTo(SingleOrDoubleBtn.mas_right).with.offset(space);
        make.bottom.mas_equalTo(self.view.mas_bottom).with.offset(bottom);
    }];
    
        sizeNumberBtn.layer.masksToBounds = SingleOrDoubleBtn.layer.masksToBounds=helpBtn.layer.masksToBounds = YES;
       sizeNumberBtn.layer.cornerRadius = SingleOrDoubleBtn.layer.cornerRadius=helpBtn.layer.cornerRadius = SingleOrDoubleBtn.frame.size.height/2;
    [self loadViewIfNeeded];
}
- (void)originAction:(id)sender {
    FristTableViewController *firstVC = [[FristTableViewController alloc]init];
    [self presentViewController:firstVC title:@"开奖号码"];
}
- (void)sizeAction:(id)sender {
    ThirdTableViewController *secondVC = [[ThirdTableViewController alloc]init];
    [self presentViewController:secondVC title:@"大小"];
}
- (void)singleOrDoubleAction:(id)sender {
    SecondTableViewController *thirdVC = [[SecondTableViewController alloc]init];
    [self presentViewController:thirdVC title:@"单双"];
}

- (void)helpAction:(id)sender {
    NSString *url = [NSString stringWithFormat:@"%@/other/aboutus",LOTTERY_HOST_NAME];
    LNWebViewController *webView = [[LNWebViewController alloc]initWithURL:[NSURL URLWithString:url]];
    [self presentViewController:webView title:@"关于我们"];
}
- (void)presentViewController:(UIViewController *)viewControllerToPresent title:(NSString *)title{
    UINavigationController *na = [[UINavigationController alloc]initWithRootViewController:viewControllerToPresent];
    na.title = title;
    [self presentViewController:na animated:NO completion:nil];
}

- (AVAudioPlayer *)audioPlayer{
    if (!_audioPlayer) {
        NSURL *fileURL = [[NSBundle mainBundle]URLForResource:@"kaijiang" withExtension:@".mp3"];
        // 2.创建 AVAudioPlayer 对象
        self.audioPlayer = [[AVAudioPlayer alloc]initWithContentsOfURL:fileURL error:nil];
        // 3.打印歌曲信息
        NSString *msg = [NSString stringWithFormat:@"音频文件声道数:%ld\n 音频文件持续时间:%g",(unsigned long)self.audioPlayer.numberOfChannels,self.audioPlayer.duration];
        NSLog(@"%@",msg);
        // 4.设置循环播放
        self.audioPlayer.numberOfLoops = -1;
        self.audioPlayer.delegate = self;
        // 5.开始播放
        

    }
    return _audioPlayer;
}
- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    [self.audioPlayer stop];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
/*  UIImageView 动画   */
-(void)gifPlay1  {
    
    UIImageView* animatedImageView = [[UIImageView alloc] init];
    animatedImageView.animationImages =@[[UIImage imageNamed:@"kaijiang01"],                                           [UIImage imageNamed:@"kaijiang02"],                                           [UIImage imageNamed:@"kaijiang03"],                                           ];
    animatedImageView.animationDuration = 1.0f;
    animatedImageView.animationRepeatCount = 0;
    [self.backGifView addSubview: animatedImageView];
    [animatedImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.right.bottom.mas_equalTo(self.backGifView);
    }];
    [animatedImageView startAnimating];
}

- (void)checkUpdate{
    [[UserStore sharedInstance]version_update:nil sucess:^(NSURLSessionDataTask *task, id responseObject) {
        NSNumber *code = [responseObject objectForKey:@"code"];
        NSInteger codeInteger = [code integerValue];
        NSNumber *mode = [responseObject objectForKey:@"mode"];
        NSInteger modeInteger = [mode integerValue];
        NSString *title = [responseObject objectForKey:@"title"];
        NSString *message = [responseObject objectForKey:@"message"];
        NSString * download_url = [responseObject objectForKey:@"download_url"];
        if (codeInteger==1) {
            if (modeInteger==0) {
                [self accordingUpdate:title content:message downloadURL:download_url type:YES];
                
            }else{
                [self accordingUpdate:title content:message downloadURL:download_url type:NO];
            }
        }
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        
    }];
}
- (void)accordingUpdate:(NSString *)title content:(NSString *)message downloadURL:(NSString *)downloadUrl type:(BOOL)isAccord{
    
    CKAlertViewController *alertVC = [CKAlertViewController alertControllerWithTitle:title  message:message ];
    
    CKAlertAction *cancel = [CKAlertAction actionWithTitle:@"我知道了" handler:^(CKAlertAction *action) {
        NSLog(@"点击了 %@ 按钮",action.title);
    }];
    
    CKAlertAction *sure = [CKAlertAction actionWithTitle:@"立即更新" handler:^(CKAlertAction *action) {
        NSLog(@"点击了 %@ 按钮",action.title);
        [self didSelectedSureButtonClick:downloadUrl];
    }];
    
    //    CKAlertAction *skip = [CKAlertAction actionWithTitle:@"跳过此版本" handler:^(CKAlertAction *action) {
    //        [[NSUserDefaults standardUserDefaults]setBool:YES forKey:appid];
    //    }];
    
    
    
    if (isAccord) {
        [alertVC addAction:sure];
    }else{
        
        [alertVC addAction:cancel];
        //[alertVC addAction:skip];
        [alertVC addAction:sure];
    }
    //    if ([[NSUserDefaults standardUserDefaults] boolForKey:appid]) {
    //        return;
    //    }
    [self presentViewController:alertVC animated:NO completion:nil];
}
- (void)didSelectedSureButtonClick:(NSString *)download_url{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:download_url]];
}
#pragma mark -网络状态监测
- (void)AFNetworkReachabilityStatus{
    __weak MainViewController *weakSelf = self;
    AFNetworkReachabilityManager *manager = [AFNetworkReachabilityManager sharedManager];
    
    [manager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        
        switch (status) {
            case AFNetworkReachabilityStatusUnknown:
                
                break;
                
            case AFNetworkReachabilityStatusNotReachable:
                NSLog(@"不可达的网络(未连接)");
                break;
                
            case AFNetworkReachabilityStatusReachableViaWWAN:
                // [weakSelf checkReviewTheStatus];
                
                [weakSelf loadData];
                NSLog(@"2G,3G,4G...的网络");
                break;
                
            case AFNetworkReachabilityStatusReachableViaWiFi:
                [weakSelf loadData];
                
                NSLog(@"wifi的网络");
                break;
            default:
                break;
        }
    }];
    [manager startMonitoring];
    
}
@end
