//
//  BaseViewController.h
//  LotteryInformation
//
//  Created by 邹壮壮 on 2017/2/20.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LITableViewCell.h"
#import <MJRefresh/MJRefresh.h>
#import "UserStore.h"
#import "OpencodeModel.h"
#define kScaleW ([[UIScreen mainScreen]bounds].size.width/375.f)
#define kScreenWidth [[UIScreen mainScreen] bounds].size.width
#define SCREEN_HEIGHT self.view.frame.size.height
#define headerHeight 30
@interface BaseViewController : UIViewController

@end
