//
//  BaseViewController.m
//  LotteryInformation
//
//  Created by 邹壮壮 on 2017/2/20.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "BaseViewController.h"
#import "UIColor+Extension.h"
@interface BaseViewController ()

@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = [self appName];
    [self titleView];
    //修改leftBarButton
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(0, 0, 20, 20);
    [button setBackgroundImage:[UIImage imageNamed:@"箭头"] forState:UIControlStateNormal];
    UIBarButtonItem *left = [[UIBarButtonItem alloc]initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = left;
    [button addTarget:self  action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    // Do any additional setup after loading the view.
}
- (void)back{
    [self dismissViewControllerAnimated:NO completion:nil];
}
- (void)titleView{
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 64, kScreenWidth, headerHeight)];
    [self.view addSubview:view];
    view.backgroundColor = [UIColor colorWithHexString:@"#70a19e"];
    NSString *name = @"2017021769";
    UIFont *font = [UIFont systemFontOfSize:13*kScaleW];
    CGSize size = [name sizeWithAttributes:@{NSFontAttributeName:font}];
    UILabel *nameL = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, size.width, headerHeight)];
    nameL.text = @"期数";
    nameL.textAlignment = NSTextAlignmentCenter;
    [view addSubview:nameL];
    
    UILabel *line1 = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(nameL.frame), 0, 1, headerHeight)];
    line1.backgroundColor = [UIColor blackColor];
    [view addSubview:line1];
    CGFloat h = (kScreenWidth -size.width)/9;
    UILabel *numberL = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(line1.frame), 0, h*5, headerHeight)];
    numberL.text = @"开奖号码";
    numberL.textAlignment = NSTextAlignmentCenter;
    [view addSubview:numberL];
    UILabel *line2 = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(numberL.frame), 0, 1, headerHeight)];
    line2.backgroundColor = [UIColor blackColor];
    [view addSubview:line2];
    
    UILabel *sumL = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(line2.frame), 0, h*4, headerHeight)];
    sumL.text = @"总和";
    sumL.textAlignment = NSTextAlignmentCenter;
    [view addSubview:sumL];
    
}
-(NSString *)appName
{
    return [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleName"];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
