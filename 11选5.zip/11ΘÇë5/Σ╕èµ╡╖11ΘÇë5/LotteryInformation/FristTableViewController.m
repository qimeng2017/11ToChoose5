//
//  FristTableViewController.m
//  LotteryInformation
//
//  Created by 邹壮壮 on 2017/2/21.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "FristTableViewController.h"

#import "XTWithdrawalPlaceHolder.h"
@interface FristTableViewController ()<UITableViewDelegate,UITableViewDataSource,XTWithdrawalPlaceHolderDelegate>
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) XTWithdrawalPlaceHolder *placeHolderView;
@end

@implementation FristTableViewController

- (NSMutableArray *)dataArray{
    if (_dataArray == nil) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"开奖号码";
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 64+headerHeight, kScreenWidth, SCREEN_HEIGHT - 64-headerHeight) style:UITableViewStylePlain];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self.view addSubview:self.tableView];
    
    self.tableView.tableFooterView = [[UIView alloc]init];
    NSString *name = @"2017021769";
    UIFont *font = [UIFont systemFontOfSize:13*kScaleW];
    CGSize size = [name sizeWithAttributes:@{NSFontAttributeName:font}];
    CGFloat h = (kScreenWidth -size.width)/9;
    self.tableView.rowHeight = h+2;
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0) {
        [self.tableView setSeparatorInset:(UIEdgeInsetsMake(0, 0, 0, 0))];
    }
    [self refreshHeader];
    self.edgesForExtendedLayout = UIRectEdgeAll;
    self.tableView.contentInset = UIEdgeInsetsMake(0.0f, 0.0f, CGRectGetHeight(self.tabBarController.tabBar.frame), 0.0f);
    [self nodata];
}
- (void)nodata{
    _placeHolderView = [[XTWithdrawalPlaceHolder alloc]initWithFrame:CGRectMake(0, 0, self.tableView.frame.size.width, self.tableView.frame.size.height) emptyOverlay:@"点击重试" imageView:nil];
    _placeHolderView.delegate = self;
    
    [self.tableView addSubview:_placeHolderView];
    _placeHolderView.hidden = YES;
}
- (void)emptyOverlayClicked:(id)sender{
    [self loadNewData];
}
- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
}


- (void)refreshHeader{
    MJRefreshNormalHeader*header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadNewData)];
    // 设置文字
    [header setTitle:@"下拉刷新" forState:MJRefreshStateIdle];
    [header setTitle:@"刷新数据" forState:MJRefreshStatePulling];
    [header setTitle:@"加载中..." forState:MJRefreshStateRefreshing];
    
    // 设置字体
    header.stateLabel.font = [UIFont systemFontOfSize:15];
    header.lastUpdatedTimeLabel.font = [UIFont systemFontOfSize:14];
    
    // 设置颜色
    header.stateLabel.textColor = [UIColor grayColor];
    header.lastUpdatedTimeLabel.textColor = [UIColor grayColor];
    
    // 马上进入刷新状态
    [header beginRefreshing];
    
    // 设置刷新控件
    self.tableView.mj_header = header;
}
- (void)loadNewData{
    
    if (_dataArray.count > 0) {
        [_dataArray removeAllObjects];
    }
    
    [UserStore getAnalyseopencode:kcode sucess:^(NSURLSessionDataTask *task, id responseObject) {
        _placeHolderView.hidden = YES;
        NSNumber *codeNum = [responseObject objectForKey:@"code"];
        NSInteger code = [codeNum integerValue];
        if (code == 1) {
            NSArray *arr = [responseObject objectForKey:@"open_data"];
            for (NSDictionary *dict in arr) {
                OpencodeModel *model = [[OpencodeModel alloc]initWithDictionary:dict error:nil];
                [self.dataArray addObject:model];
            }
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.tableView reloadData];
            [self.tableView.mj_header endRefreshing];
        });
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        if (self.dataArray.count== 0) {
            _placeHolderView.hidden = NO;
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.tableView reloadData];
            [self.tableView.mj_header endRefreshing];
        });
    }];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return _dataArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *firstCellIdentifier = @"firstCellIdentifier";
    LITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:firstCellIdentifier];
    if (!cell) {
        cell = [[LITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:firstCellIdentifier];
    }
    if (_dataArray.count > indexPath.row) {
        OpencodeModel *model = [_dataArray objectAtIndex:indexPath.row];
        [cell name:model.issueno lotteryNumbers:model.numberArr sumArray:model.sumDataArray index:1];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

@end
