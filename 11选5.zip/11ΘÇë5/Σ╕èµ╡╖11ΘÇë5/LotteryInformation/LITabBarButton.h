//
//  LITabBarButton.h
//  LotteryInformation
//
//  Created by 邹壮壮 on 2017/2/20.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum :NSUInteger{
   LITabBarButtonStatusSelected,
   LITabBarButtonStatusUnselected
}LITabBarButtonType;

@protocol LITabBarButtonDelegate <NSObject>

- (void)LIChoiceButtonSelectedIndex:(NSUInteger)index;

@end
@interface LITabBarButton : UIButton
@property (nonatomic, assign) NSUInteger index;
@property (nonatomic, weak)id<LITabBarButtonDelegate>delegate;
@property (nonatomic,assign)LITabBarButtonType choiceType;
+(id)initWithButtonFrame:(CGRect)frame selectedIndex:(NSUInteger)index selectedImage:(UIImage *)seledtedImage normalImage:(UIImage *)normalImage;
@end
