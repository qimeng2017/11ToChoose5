//
//  LITabBarButton.m
//  LotteryInformation
//
//  Created by 邹壮壮 on 2017/2/20.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "LITabBarButton.h"

static NSMutableDictionary *_normalImageDict;
static NSMutableDictionary *_selectedImageDict;
static NSMutableArray      *_normalImageArray;
static NSMutableArray      *_selectedImageArray;
@implementation LITabBarButton
- (id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        
    }
    return self;
}
+(id)initWithButtonFrame:(CGRect)frame selectedIndex:(NSUInteger)index selectedImage:(UIImage *)seledtedImage normalImage:(UIImage *)normalImage{
    if (!_normalImageDict) {
        _normalImageDict = [NSMutableDictionary dictionaryWithCapacity:1];
    }
    if (!_selectedImageDict) {
        _selectedImageDict = [NSMutableDictionary dictionaryWithCapacity:1];
    }
    if (!_normalImageArray) {
        _normalImageArray = [NSMutableArray arrayWithCapacity:1];
    }
    if (!_selectedImageArray) {
        _selectedImageArray = [NSMutableArray arrayWithCapacity:1];
    }
    LITabBarButton *button = [LITabBarButton buttonWithType:UIButtonTypeCustom];
    button.frame = frame;
    button.choiceType = LITabBarButtonStatusUnselected;
    button.index = index;
    NSString *imageKey = [NSString stringWithFormat:@"%lu",(unsigned long)index];
    if (normalImage) {
        [button setImage:normalImage forState:UIControlStateNormal];
        [_normalImageDict setObject:normalImage forKey:imageKey];
    }
    if (seledtedImage) {
        [button setImage:seledtedImage forState:UIControlStateSelected];
        [_selectedImageDict setObject:seledtedImage forKey:imageKey];
    }
    [button addTarget:self action:@selector(buttonTouchAction:) forControlEvents:UIControlEventTouchUpInside];
    if (button.choiceType == LITabBarButtonStatusUnselected) {
        [_normalImageArray addObject:button];
    }else{
        [_selectedImageArray addObject:button];
    }
    return button;
    
}
+ (void)buttonTouchAction:(LITabBarButton *)button{
    if (button.choiceType == LITabBarButtonStatusSelected) {
        return;
    }
    button.choiceType = LITabBarButtonStatusSelected;
}
- (void)setChoiceType:(LITabBarButtonType)choiceType{
    _choiceType = choiceType;
    NSString *strIndex = [NSString stringWithFormat:@"%lu",(unsigned long)self.index];
    if (choiceType == LITabBarButtonStatusSelected) {
        if (_selectedImageDict[strIndex]) {
            [self setImage:_selectedImageDict[strIndex] forState:UIControlStateNormal];
        }
    }else{
        if (_normalImageDict[strIndex]) {
            [self setImage:_normalImageDict[strIndex] forState:UIControlStateNormal];
        }
    }
    if (choiceType == LITabBarButtonStatusSelected) {
        for (int i=0; i<_selectedImageArray.count; i++) {
            LITabBarButton *button = [_selectedImageArray objectAtIndex:i];
            button.choiceType = LITabBarButtonStatusUnselected;
        }
        [_normalImageArray removeObject:self];
        [_selectedImageArray addObject:self];
        if (self.delegate&&[self.delegate respondsToSelector:@selector(LIChoiceButtonSelectedIndex:)]) {
            [self.delegate LIChoiceButtonSelectedIndex:self.index];
        }
    }else if(_choiceType == LITabBarButtonStatusUnselected){
        [_normalImageArray addObject:self];
        [_selectedImageArray removeObject:self];
    }
    
}
@end
