//
//  LITabBarViewController.m
//  LotteryInformation
//
//  Created by 邹壮壮 on 2017/2/20.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "LITabBarViewController.h"
#import "LITabBarButton.h"
#import "FristTableViewController.h"
#import "SecondTableViewController.h"
#import "ThirdTableViewController.h"
@interface LITabBarViewController ()<LITabBarButtonDelegate>

@end

@implementation LITabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    FristTableViewController *firstVC = [[FristTableViewController alloc]init];
    UINavigationController *firstNaviagte = [[UINavigationController alloc]initWithRootViewController:firstVC];
    
    SecondTableViewController *secondVC = [[SecondTableViewController alloc]init];
    UINavigationController *secondNaviagte = [[UINavigationController alloc]initWithRootViewController:secondVC];
    
    ThirdTableViewController*ThirdVC = [[ThirdTableViewController alloc]init];
    UINavigationController *ThirdNaviagte = [[UINavigationController alloc]initWithRootViewController:ThirdVC];
    self.viewControllers = @[firstNaviagte,secondNaviagte,ThirdNaviagte];
    [self crecteButton];
    self.selectedViewController = firstNaviagte;
    // Do any additional setup after loading the view.
}
- (void)crecteButton{
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    UIImageView *barImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, screenWidth, 49)];
    barImageView.backgroundColor = [UIColor whiteColor];
    barImageView.userInteractionEnabled = YES;
    [self.tabBar addSubview:barImageView];
    NSUInteger count = self.viewControllers.count;
    for (int i = 0; i<count; i++) {
        NSString *selectedStr = [NSString stringWithFormat:@"tabbar_%d_hl",i];
        NSString *normalStr = [NSString stringWithFormat:@"tabbar_%d",i];
        LITabBarButton *button = [LITabBarButton initWithButtonFrame:CGRectMake((screenWidth/count)*i, 0, screenWidth/count, 49) selectedIndex:i selectedImage:[UIImage imageNamed:selectedStr] normalImage:[UIImage imageNamed:normalStr]];
        
        button.delegate = self;
//        if (i == 1) {
//            button.frame = CGRectMake(0, 0, screenWidth/count, screenWidth/count);
//            button.center=CGPointMake(self.tabBar.center.x, self.tabBar.frame.size.height/3);
//            button.layer.masksToBounds = YES;
//            
//            button.layer.cornerRadius = (screenWidth/count)/2;
//            button.backgroundColor = [UIColor greenColor];
//        }
        if (i==0) {
            button.choiceType = LITabBarButtonStatusSelected;
        }
        [barImageView addSubview:button];
    }
    [self.tabBar setBackgroundImage:[self imageWithColor:[UIColor clearColor] size:self.tabBar.frame.size]];
    [self.tabBar setShadowImage:[self imageWithColor:[UIColor clearColor] size:self.tabBar.frame.size]];
}


- (void)LIChoiceButtonSelectedIndex:(NSUInteger)index{
    self.selectedViewController = self.viewControllers[index];
}
- (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size{
    CGRect rect = CGRectMake(0, 0, size.width, size.height);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return img;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
