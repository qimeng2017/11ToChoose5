//
//  LITableViewCell.h
//  LotteryInformation
//
//  Created by 邹壮壮 on 2017/2/20.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LITableViewCell : UITableViewCell
- (void)name:(NSString *)name lotteryNumbers:(NSArray *)lotterys sumArray:(NSArray *)sumarray index:(NSInteger)index;
@end
