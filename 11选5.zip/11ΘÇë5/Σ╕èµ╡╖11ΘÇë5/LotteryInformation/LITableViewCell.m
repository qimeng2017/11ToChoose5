//
//  LITableViewCell.m
//  LotteryInformation
//
//  Created by 邹壮壮 on 2017/2/20.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "LITableViewCell.h"
#import "UIColor+Extension.h"
#define kScreenWidth [[UIScreen mainScreen] bounds].size.width
#define kScaleW ([[UIScreen mainScreen]bounds].size.width/375.f)
@interface LITableViewCell ()
@property (nonatomic, strong) UILabel *nameLable;
@property (nonatomic, strong) UIView * lotteryNumberView;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSArray *lotteryNumbers;
@property (nonatomic, strong) UIView *sumView;
@property (nonatomic, strong) NSArray *sumArray;
@property (nonatomic, assign) NSInteger indexVC;
@end
@implementation LITableViewCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        _nameLable = [[UILabel alloc]init];
        _nameLable.textColor = [UIColor whiteColor];
        _nameLable.backgroundColor = [UIColor grayColor];
        _nameLable.font = [UIFont systemFontOfSize:12*kScaleW];
        _nameLable.textAlignment = NSTextAlignmentCenter;
        [self addSubview:_nameLable];
        _lotteryNumberView = [[UIView alloc]init];
        _lotteryNumberView.backgroundColor = [UIColor clearColor];
        [self addSubview:_lotteryNumberView];
        _sumView = [[UIView alloc]init];
        _sumView.backgroundColor = [UIColor clearColor];
        [self addSubview:_sumView];
    }
    return self;
}

- (void)name:(NSString *)name lotteryNumbers:(NSArray *)lotterys sumArray:(NSArray *)sumarray index:(NSInteger)index{
    _name = name;
    _lotteryNumbers = lotterys;
    _sumArray = sumarray;
    _indexVC = index;
    [self setNeedsLayout];
}

- (void)layoutSubviews{
    [super layoutSubviews];
    _nameLable.text = _name;
    NSString *name = @"2017021769";
    UIFont *font = [UIFont systemFontOfSize:13*kScaleW];
    CGSize size = [name sizeWithAttributes:@{NSFontAttributeName:font}];
    
    _nameLable.frame = CGRectMake(0, 0, size.width, self.frame.size.height);
    
    CGFloat lableWidth = (kScreenWidth-CGRectGetWidth(_nameLable.frame))/(_lotteryNumbers.count+_sumArray.count);
    //开奖号码
    for (UIView *view in _lotteryNumberView.subviews) {
        [view removeFromSuperview];
    }
    CGFloat widthX = 0;
    for (NSInteger i= 0; i<_lotteryNumbers.count; i++) {
        UILabel*lable = [[UILabel alloc]init];
        lable.textColor = [UIColor whiteColor];
        NSString * text = [NSString stringWithFormat:@"%@",[_lotteryNumbers objectAtIndex:i]];
        if (_indexVC == 1) {
           
            
            NSArray *colors = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"color" ofType:@"plist"]];
            for (NSDictionary *dict in colors) {
                NSString *content = [dict objectForKey:@"content"];
                NSString *color = [NSString stringWithFormat:@"#%@",[dict objectForKey:@"color"]];
                if ([content isEqualToString:text]) {
                    lable.backgroundColor = [UIColor colorWithHexString:color];
                    break;
                }
            }
        }else if(_indexVC == 2){
           
            NSInteger textCount = [text integerValue];
            if (textCount%2==0) {
                text = @"双";
                lable.backgroundColor = [UIColor colorWithHexString:@"#e19758"];
            }else{
                text = @"单";
                lable.backgroundColor = [UIColor colorWithHexString:@"#5dabdb"];
            }
        }else if (_indexVC == 3){
            NSInteger textCount = [text integerValue];
            if (textCount>=6) {
                text = @"大";
                lable.backgroundColor = [UIColor colorWithHexString:@"#5badd5"];
            }else{
                text = @"小";
                lable.backgroundColor = [UIColor colorWithHexString:@"#eb925a"];
            }
        }
        
        lable.text = text;
        [lable sizeToFit];
        lable.textAlignment = NSTextAlignmentCenter;
        
        lable.font = [UIFont systemFontOfSize:13*kScaleW];
        [_lotteryNumberView addSubview:lable];
        lable.frame = CGRectMake(lableWidth*i, 0, lableWidth, lableWidth);
        widthX+=lableWidth;
        
    }
   
    _lotteryNumberView.frame = CGRectMake(CGRectGetMaxX(_nameLable.frame), 0, widthX, lableWidth);
    widthX = 0;
    //总和
    for (UIView *view in _sumView.subviews) {
        [view removeFromSuperview];
    }
    for (NSInteger i= 0; i<_sumArray.count; i++) {
        NSString *text = [NSString stringWithFormat:@"%@",[_sumArray objectAtIndex:i]];
        UILabel*lable = [[UILabel alloc]init];
        lable.textColor = [UIColor whiteColor];
        if ([text isEqualToString:@"单"]||[text isEqualToString:@"大"]||[text isEqualToString:@"尾大"]) {
            lable.backgroundColor = [UIColor colorWithHexString:@"#ff5b85"];
        }else{
           lable.backgroundColor = [UIColor colorWithHexString:@"#cccccc"];
        }
        lable.text = text;
        [lable sizeToFit];
        lable.textAlignment = NSTextAlignmentCenter;
        
        lable.font = [UIFont systemFontOfSize:13*kScaleW];
        [_sumView addSubview:lable];
        lable.frame = CGRectMake(lableWidth*i, 0, lableWidth, lableWidth);
        widthX+=lableWidth;
        
    }
    _sumView.frame = CGRectMake(CGRectGetMaxX(_lotteryNumberView.frame), 0, widthX, lableWidth);
    
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
