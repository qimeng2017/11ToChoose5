//
//  OpencodeModel.h
//  LotteryInformation
//
//  Created by 邹壮壮 on 2017/2/20.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import <JSONModel/JSONModel.h>

@interface sum_data : JSONModel
@property (nonatomic, strong)NSString *big_small;
@property (nonatomic, strong)NSString *all_count;
@property (nonatomic, strong)NSString *end_big_small;
@property (nonatomic, strong)NSString *single_double;
@end
@interface OpencodeModel : JSONModel
@property (nonatomic, strong)NSString *number;
@property (nonatomic, strong)NSString *issueno;
@property (nonatomic, strong)sum_data *sum_data;
@property (nonatomic, strong)NSArray *numberArr;
@property (nonatomic, strong)NSArray *sumDataArray;
@end
