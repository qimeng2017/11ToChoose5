//
//  OpencodeModel.m
//  LotteryInformation
//
//  Created by 邹壮壮 on 2017/2/20.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "OpencodeModel.h"

@implementation sum_data

+(BOOL)propertyIsOptional:(NSString*)propertyName
{
    return YES;
}

@end
@implementation OpencodeModel
+(BOOL)propertyIsOptional:(NSString*)propertyName
{
    return YES;
}
- (NSArray *)numberArr{
    NSArray *array = [self.number componentsSeparatedByString:@","];
    return array;
}
- (NSArray *)sumDataArray{
    NSMutableArray *array = [NSMutableArray array];
    if (_sum_data.big_small) {
        [array addObject:_sum_data.all_count];
    }
    if (_sum_data.single_double) {
        [array addObject:_sum_data.single_double];
    }
    if (_sum_data.big_small) {
        [array addObject:_sum_data.big_small];
    }
    if (_sum_data.end_big_small) {
        [array addObject:_sum_data.end_big_small];
    }
    return array;
}
@end
