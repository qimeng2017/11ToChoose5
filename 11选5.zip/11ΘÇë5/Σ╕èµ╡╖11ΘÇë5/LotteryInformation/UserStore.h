//
//  UserStore.h
//  LotteryInformation
//
//  Created by 邹壮壮 on 2017/2/20.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^sucessCompleteBlock)(NSURLSessionDataTask *task, id responseObject);

typedef void(^failureCompleteBlock)(NSURLSessionDataTask *task, NSError * error);
@interface UserStore : NSObject
+ (UserStore *)sharedInstance;
//caipiaoid = 2001   广东11选5
+(void)getAnalyseopencode:(NSString *)caipiaoid sucess:(sucessCompleteBlock)sucessBlock failure:(failureCompleteBlock)failureBlock;
#pragma mark --版本更新
- (void)version_update:(NSString *)userid sucess:(sucessCompleteBlock)sucessBlock failure:(failureCompleteBlock)failureBlock;
@end
