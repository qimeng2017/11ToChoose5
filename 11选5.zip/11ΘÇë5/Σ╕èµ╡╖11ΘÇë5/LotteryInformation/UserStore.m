//
//  UserStore.m
//  LotteryInformation
//
//  Created by 邹壮壮 on 2017/2/20.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "UserStore.h"
#import "HRNetworkTools.h"
@implementation UserStore
+ (UserStore *)sharedInstance
{
    static UserStore *_sharedInstance = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[UserStore alloc] init];
    });
    
    return _sharedInstance;
}
+(void)getAnalyseopencode:(NSString *)caipiaoid sucess:(sucessCompleteBlock)sucessBlock failure:(failureCompleteBlock)failureBlock{
    NSString *url = [NSString stringWithFormat:@"%@/analyse/opencode?caipiaoid=%@",LOTTERY_HOST_NAME,caipiaoid];
    [[HRNetworkTools sharedNetworkTools]GET:url parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        sucessBlock(task,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failureBlock(task,error);
    }];
}
#pragma mark --版本更新
- (void)version_update:(NSString *)userid sucess:(sucessCompleteBlock)sucessBlock failure:(failureCompleteBlock)failureBlock{
   userid = @"oszDYvnjGoggsWTshIScOemfEHWU";
    NSString *url = [NSString stringWithFormat:@"https://caipiao.asopeixun.com:6688/version_update"];
    NSDictionary *parameters = @{@"appid":kappid,@"stype":kstype,@"userid":userid};
    [[HRNetworkTools sharedNetworkTools]GET:url parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        sucessBlock(task,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failureBlock(task,error);
    }];
}
@end
