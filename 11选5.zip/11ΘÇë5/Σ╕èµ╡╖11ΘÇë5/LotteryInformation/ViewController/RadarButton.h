//
//  RadarButton.h
//  LotteryInformation
//
//  Created by 邹壮壮 on 2017/2/24.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RadarButton : UIButton

@end
